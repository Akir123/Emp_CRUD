package com.emp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.emp.repository.EmpRepository;

import jakarta.servlet.http.HttpSession;

//@Controller
//@RequestMapping(path = "/user")
public class UserController {
	
//	@Autowired
//	private EmpRepository empRepository;
//	
//	public String home() {
//		return "user/home";
//	}
//	
//	@RequestMapping(path = "/logout",method = RequestMethod.GET)
//	public String logout(HttpSession s) {
//		s.removeAttribute("user");
//		return "redirect:/";
//	}
	
}
