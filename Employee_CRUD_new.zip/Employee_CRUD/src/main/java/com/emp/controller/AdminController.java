package com.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.emp.entity.Employee;
import com.emp.repository.EmpRepository;
import com.emp.service.EmpService;

import jakarta.servlet.http.HttpSession;

//@Controller
//@RequestMapping(path = "/admin",method = RequestMethod.GET)
public class AdminController {
//	
//	@Autowired
//	private EmpRepository empRepository;
//	
//	@Autowired
//	private EmpService empService;
//	
//	@RequestMapping(path = "/",method = RequestMethod.GET)
//	public String home(Model m) {
//		List<Employee> emps = empRepository.findAll();
//		m.addAttribute("emps", emps);
//		return "admin/home";
//	}
//	
//	@RequestMapping(path="/addUser",method = RequestMethod.GET)
//	public String addUser() {
//		return "admin/addUser";
//	}
//	
//	@RequestMapping(path="/addNewUser",method = RequestMethod.POST)
//	public String addNewUser(@ModelAttribute("newUser") Employee e,
//							 HttpSession s) {
//		boolean f = empService.checkEmail(e.getEmail());
//		
//		if(f) {
//			System.out.println("Email Id already exist..");
//			s.setAttribute("msg", "Email Id already exist..");
//		}else {
//			Employee user = empService.createEmp(e);
//			
//			if(user!=null) {
//				System.out.println("User Added Successfully..");
//				s.setAttribute("msg", "User Added Successfully..");
//			}else {
//				System.out.println("something went wrong on server..");
//				s.setAttribute("msg", "something went wrong on server..");
//			}
//			
//		}
//		
//		return "redirect:/admin/";
//	}
//	
//	@RequestMapping(path="/update/{id}",method = RequestMethod.GET)
//	public String editFrom(@PathVariable("id") Long id, Model m) {
//		Employee user = empRepository.findById(id).get();
//		m.addAttribute("e", user);
//		return "admin/editUser";
//	}
//	
//	@RequestMapping(path="/update_user",method = RequestMethod.POST)
//	public String updateUser(@ModelAttribute("updateUser") Employee u,
//							 HttpSession s) {
//		Employee userUpdated = empRepository.save(u);
//		if(userUpdated!=null) {
//			System.out.println("User Updated Successfully..");
//			s.setAttribute("msg", "User Updated Successfully..");
//		}
//		return "redirect:/admin/";
//	}
//	
//	@RequestMapping(path="/delete/{id}",method = RequestMethod.GET)
//	public String deleteUser(@PathVariable("id") Long id, Model m,
//							 HttpSession s) {
//		empRepository.deleteById(id);
//		System.out.println("user deleted successfully..");
//		s.setAttribute("msg", "user deleted successfully..");
//		return "redirect:/admin/";
//	}
//	
//	@RequestMapping(path = "/logout",method = RequestMethod.GET)
//	public String logout(HttpSession s) {
//		s.removeAttribute("user");
//		return "redirect:/";
//	}
	
}
