package com.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.emp.entity.Employee;
import com.emp.repository.EmpRepository;
import com.emp.service.EmpService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {
	@Autowired
	private EmpRepository empRepository;

	@Autowired
	private EmpService empService;

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String home(Model m) {
		List<Employee> allEmployees = empService.getAllEmployees();
		
		m.addAttribute("emps", allEmployees);
		return "index";
	}

	@RequestMapping(path = "/signin", method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	@RequestMapping(path = "/login",method = RequestMethod.POST)
	public String loginProcessing(@RequestParam("email") String email,
								  @RequestParam("password") String password,
								  HttpSession s,
								  HttpServletRequest req,
								  Model m) {
		
		Employee user = empService.findByEmailAndPassword(email, password);
		if(user==null) {
			s.setAttribute("msg", "Invalid Details!!,try again..");
			return "redirect:/signin";
		} else {
			String contextPath = req.getContextPath();
			System.out.println(contextPath);
			s.setAttribute("user", user);
//			if(user.getUserType().equals("ADMIN")) {
//				return "redirect:/admin";
//			} else if(user.getUserType().equals("USER")) {
//				return "redirect:/user";
//			}else {
//			return "redirect:/signin";
//			}
			return "redirect:/user";
		}		
		
	}

	@RequestMapping(path = "/register", method = RequestMethod.GET)
	public String register() {
		return "register";
	}

	@RequestMapping(path = "/createEmp", method = RequestMethod.POST)
	public String createEmp(@ModelAttribute Employee e, HttpSession s) {
		boolean f = empService.checkEmail(e.getEmail());

		if (f) {
			System.out.println("Email id already exist...");
			s.setAttribute("msg", "Email id already exist...");
		} else {
			Employee emp = empService.createEmp(e);
			if (emp != null) {
				System.out.println("registered successfully..");
				s.setAttribute("msg", "registered successfully..");
			} else {
				System.out.println("something went wron on server..");
				s.setAttribute("msg", "something went wron on server..");
			}
		}

		return "redirect:/register";
	}

//	admin start 
	@RequestMapping(path = "/admin",method = RequestMethod.GET)
	public String adminHome(Model m) {
		List<Employee> emps = empRepository.findAll();
		m.addAttribute("emps", emps);
		return "admin/home";
	}
	
	@RequestMapping(path="/admin/addUser",method = RequestMethod.GET)
	public String addUser() {
		return "admin/addUser";
	}
	
	@RequestMapping(path="/admin/addNewUser",method = RequestMethod.POST)
	public String addNewUser(@ModelAttribute("newUser") Employee e,
							 HttpSession s) {
		boolean f = empService.checkEmail(e.getEmail());
		
		if(f) {
			System.out.println("Email Id already exist..");
			s.setAttribute("msg", "Email Id already exist..");
		}else {
			Employee user = empService.createEmp(e);
			
			if(user!=null) {
				System.out.println("User Added Successfully..");
				s.setAttribute("msg", "User Added Successfully..");
			}else {
				System.out.println("something went wrong on server..");
				s.setAttribute("msg", "something went wrong on server..");
			}
			
		}
		
		return "redirect:/admin/";
	}
	
	@RequestMapping(path="/admin/update/{id}",method = RequestMethod.GET)
	public String editFrom(@PathVariable("id") Long id, Model m) {
		Employee user = empRepository.findById(id).get();
		m.addAttribute("e", user);
		return "admin/editUser";
	}
	
	@RequestMapping(path="/admin/update_user",method = RequestMethod.POST)
	public String updateUser(@ModelAttribute("updateUser") Employee u,
							 HttpSession s) {
		Employee userUpdated = empRepository.save(u);
		if(userUpdated!=null) {
			System.out.println("User Updated Successfully..");
			s.setAttribute("msg", "User Updated Successfully..");
		}
		return "redirect:/admin/";
	}
	
	@RequestMapping(path="/admin/delete/{id}",method = RequestMethod.GET)
	public String deleteUser(@PathVariable("id") Long id, Model m,
							 HttpSession s) {
		empRepository.deleteById(id);
		System.out.println("user deleted successfully..");
		s.setAttribute("msg", "user deleted successfully..");
		return "redirect:/admin/";
	}
//	admin end
	
//	user code
	@RequestMapping(path = "/user",method = RequestMethod.GET)
	public String userHome() {
		return "user/home";
	}
	
	@RequestMapping(path = "/logout",method = RequestMethod.GET)
	public String logout(HttpSession s) {
		s.removeAttribute("user");
		return "redirect:/";
	}
	
}
