package com.emp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.entity.Employee;
import com.emp.repository.EmpRepository;

@Service
public class EmpServiceImpl implements EmpService {

	@Autowired
	private EmpRepository empRepository;
	
	@Override
	public boolean checkEmail(String email) {
		boolean f=empRepository.existsByEmail(email);
		return f;
	}

	@Override
	public Employee createEmp(Employee e) {
		e.setPassword(e.getPassword());
//		e.setUserType("USER");
		Employee emp = empRepository.save(e);
		return emp;
	}

	@Override
	public Employee findByEmailAndPassword(String email, String password) {
		Employee user = empRepository.findByEmailAndPassword(email, password);
		return user;
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> emp = empRepository.findAll();
		return emp;
	}

}
