package com.emp.service;

import java.util.List;

import com.emp.entity.Employee;

public interface EmpService {
	public boolean checkEmail(String email);
	public Employee createEmp(Employee e);
	public Employee findByEmailAndPassword(String email, String password);
	public List<Employee> getAllEmployees();
}
